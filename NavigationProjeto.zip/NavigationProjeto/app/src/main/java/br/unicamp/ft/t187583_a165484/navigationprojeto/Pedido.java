package br.unicamp.ft.t187583_a165484.navigationprojeto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Pedido implements Serializable {

    private int NumeroPedido;
    private List<Bebida> bebidas;
    private List<Comida> comidas;

    public int getNumeroPedido() {
        return NumeroPedido;
    }

    public void setNumeroPedido(int numeroPedido) {
        NumeroPedido = numeroPedido;
    }

    public List<Bebida> getBebidas() {
        return bebidas;
    }

    public void setBebidas(List<Bebida> bebidas) {
        this.bebidas = bebidas;
    }

    public List<Comida> getComidas() {
        return comidas;
    }

    public Pedido(){
        comidas = new ArrayList<Comida>();
        bebidas = new ArrayList<Bebida>();
    }

    public void setComidas(List<Comida> comidas) {
        this.comidas = comidas;
    }


}
