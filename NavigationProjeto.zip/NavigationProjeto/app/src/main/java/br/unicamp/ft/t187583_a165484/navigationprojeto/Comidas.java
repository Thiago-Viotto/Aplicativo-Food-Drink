package br.unicamp.ft.t187583_a165484.navigationprojeto;

import java.util.List;

public class Comidas {

    public static Comida[] comidas = {
            new Comida(1, "X-Burger", R.drawable.xburger, "Lanche com hambúrguer, queijo, tomate e alface" ,12.99 ),
            new Comida(2, "Pastel de queijo", R.drawable.pastelqueijo, "Pastel de queijo" , 7.50),
            new Comida(3, "Macarrão", R.drawable.macarrao, "Macarrão italiano com molho de tomate, presunto, queijo, carne moida", 10),
            new Comida(4, "Camarão", R.drawable.camarao, "Camarão fresquinho com cebola, tomate e tempero especial", 45),
            new Comida(5, "Lasanha", R.drawable.lasanha, "Lasanha com molho de tomate, carne, presunto, queijo", 24.5),
            new Comida(6, "Picanha", R.drawable.picanha, "Picanha com cebola", 36.7),
    };

}