package br.unicamp.ft.t187583_a165484.navigationprojeto;

public class Bebidas {

    public static Bebida[] bebidas = {
            new Bebida("1", "Água com gás", R.drawable.aguacomgas200ml, "Água com gás 200ml",3.20),
            new Bebida("2", "Coca cola", R.drawable.cocacola200ml, "Refrigerante coca cola 200ml",4.00),
            new Bebida("3", "Suco de laranja", R.drawable.sucolaranja200ml, "Suco de laranja 200ml", 4.00),
            new Bebida("4", "H20", R.drawable.h20500ml, "H20 500ml", 4.00),
            new Bebida("5", "Copo de shop", R.drawable.shop, "Copo de shop de 500ml", 8),
            new Bebida("6", "Fanta de laranja", R.drawable.fanta500ml, "Fanta de laranja 500ml", 5.5),
            new Bebida("7", "Vinho Pérgola", R.drawable.vinhopergola, "Taça de vinho pérgola", 8),

    };
}
