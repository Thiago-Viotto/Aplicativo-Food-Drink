package br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces;

public interface OnCadastroRequest {
    void request();
}
