package br.unicamp.ft.t187583_a165484.navigationprojeto;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class PedidoFragmento extends android.support.v4.app.Fragment  {


    View view;
    TextView txtTotal;
    Bundle bundle = new Bundle();
    Pedido pedido = new Pedido();
    List<Comida> comidas = new ArrayList<Comida>();
    List<Bebida> bebidas = new ArrayList<Bebida>();
    public PedidoFragmento() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (view == null){
            view = inflater.inflate(R.layout.fragment_pedido_fragmento, container, false);
        }

        ListView listView = (ListView) view.findViewById(R.id.lista);
        ListView listView2 = (ListView) view.findViewById(R.id.lista2);

        txtTotal = view.findViewById(R.id.txtTotal);

        ArrayAdapter<Comida> listViewAdapter = new ArrayAdapter<Comida>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                comidas
        );

        ArrayAdapter<Bebida> listViewAdapter2 = new ArrayAdapter<Bebida>(
                getActivity(),
                android.R.layout.simple_list_item_1,
                bebidas);


        DecimalFormat df = new DecimalFormat("0.##");
        double preco = precoBebida(bebidas)+precoCardapio(comidas);

        txtTotal.setText("Total: "+(df.format(preco)));
        //txtTotal.setText("Total: "+(df.format(precoBebida(bebidas))));

        listView.setAdapter(listViewAdapter);
        listView2.setAdapter(listViewAdapter2);

        return view;
    }

    public void setArgumentsPedido(Pedido p){
        comidas = p.getComidas() ;
    }

    public double precoCardapio (List<Comida> comidas){
        double total = 0;
        for (Comida c : comidas ){
            total += c.getPreco() * c.getQuantidade();
        }
        return total;
    }

    public void setArgumentsPedidoBebidas(Pedido p){
        bebidas = p.getBebidas() ;
    }

    public double precoBebida (List<Bebida> bebidas){
        double total = 0;
        for (Bebida b : bebidas ){
            total += b.getPreço() * b.getQuantidade();
        }
        return total;
    }

}
