package br.unicamp.ft.t187583_a165484.navigationprojeto;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnBebidaRequest;
import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnCadastroRequest;
import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnCardapioRequest;
import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnCategoriaRequest;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    public FragmentManager fragmentManager;
    public Pedido pedido = new Pedido();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        fragmentManager = getSupportFragmentManager();

        if(savedInstanceState == null){
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            //navigationView.getMenu().getItem(1).setChecked(true);
            //onNavigationItemSelected(navigationView.getMenu())
            onNavigationItemSelected(navigationView.getMenu().findItem(R.id.nav_cardapio));
            onNavigationItemSelected(navigationView.getMenu().findItem(R.id.nav_bebidas));
            onNavigationItemSelected(navigationView.getMenu().findItem(R.id.nav_home));
            //TelaPrincipalFragment f2 = new TelaPrincipalFragment();
            fragmentTransaction.commit();
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Fragment settingsFragment = fragmentManager.findFragmentByTag("settings");
            if(settingsFragment == null){
                settingsFragment = new SettingsFragment();
            }
            replaceFragment(settingsFragment, "settigns");
            return true;
        }
        if(id == R.id.it_email){
            Fragment mailFragment = fragmentManager.findFragmentByTag("mail");
            if(mailFragment == null){
                mailFragment = new MailFragment();
            }
            replaceFragment(mailFragment, "mail");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Fragment telaPrincipalFragment = fragmentManager.findFragmentByTag("telaPrincipal");
            if (telaPrincipalFragment == null) {
                telaPrincipalFragment = new TelaPrincipalFragment();
            }
                ((TelaPrincipalFragment) telaPrincipalFragment).setOnCardapioRequest(new OnCardapioRequest() {
                    @Override
                    public void request() {
                        Fragment cardapioFragment = fragmentManager.findFragmentByTag("cardapio");
                        if (cardapioFragment == null) {
                            cardapioFragment = new CardapioFragment();
                        }
                        replaceFragment(cardapioFragment, "cardapio");
                    }

                    @Override
                    public void requestList(Comida c, int pos) {
                    }
                });

            ((TelaPrincipalFragment)telaPrincipalFragment).setOnBebidaRequest(new OnBebidaRequest() {
                @Override
                public void onRequest() {
                    Fragment bebidaFragment = fragmentManager.findFragmentByTag("bebida");
                    if (bebidaFragment == null) {
                        bebidaFragment = new BebidasFragment();
                    }
                    replaceFragment(bebidaFragment, "bebida");
                }

                @Override
                public void requestList(Bebida b, int pos) {

                }


            });

            ((TelaPrincipalFragment)telaPrincipalFragment).setOnCategoriaRequest(new OnCategoriaRequest() {
                @Override
                public void request() {
                    Fragment categoriaFragment = fragmentManager.findFragmentByTag("categoria");
                    if (categoriaFragment == null) {
                        categoriaFragment = new CategoriaFragment();
                    }
                    replaceFragment(categoriaFragment, "categoria");
                }
            });
            ((TelaPrincipalFragment)telaPrincipalFragment).setOnCadastroRequest(new OnCadastroRequest() {
                @Override
                public void request() {
                    Fragment cadastroFragment = fragmentManager.findFragmentByTag("cadastro");
                    if(cadastroFragment == null){
                        cadastroFragment = new CadastroFragment();
                    }
                    replaceFragment(cadastroFragment,"cadastro");
                }
            });
                replaceFragment(telaPrincipalFragment, "telaPrincipal");
                Toast.makeText(MainActivity.this, "Você entrou na tela principal", Toast.LENGTH_SHORT).show();
            }else if (id == R.id.nav_cardapio) {
            Fragment cardapioFragment = fragmentManager.findFragmentByTag("cardapio");
            if(cardapioFragment == null) {
                cardapioFragment = new CardapioFragment();
            }
                ((CardapioFragment) cardapioFragment).setOnCardapioRequest(new OnCardapioRequest() {

                    @Override
                    public void request() {
                    }

                    @Override
                    public void requestList(Comida c, int pos) {
                        boolean naoTem = true;
                        for(Comida co : pedido.getComidas()){
                            if(co.getId() == c.getId()){
                                int qtd;
                                qtd = pedido.getComidas().get(pos).getQuantidade();
                                qtd++;
                                pedido.getComidas().get(pos).setQuantidade(qtd);
                                naoTem = false;
                                break;
                            }
                        }
                        if(naoTem) {
                            pedido.getComidas().add(c);
                        }
                        Toast.makeText(MainActivity.this,"Adicionado " + c.getNome(),Toast.LENGTH_SHORT).show();
                    }
                });

                replaceFragment(cardapioFragment, "cardapio");
        } else if (id == R.id.nav_bebidas) {
            Fragment bebidaFragment = fragmentManager.findFragmentByTag("bebida");
            if(bebidaFragment == null){
                bebidaFragment = new BebidasFragment();
            }
            ((BebidasFragment) bebidaFragment).setOnBebidaRequest(new OnBebidaRequest() {

                @Override
                public void onRequest() {

                }

                @Override
                public void requestList(Bebida b, int pos) {
                    boolean naoTem = true;
                    for(Bebida be : pedido.getBebidas()){
                        if(be.getId() == b.getId()){
                            int qtd;
                            qtd = pedido.getBebidas().get(pos).getQuantidade();
                            qtd++;
                            pedido.getBebidas().get(pos).setQuantidade(qtd);
                            naoTem = false;
                            break;
                        }
                    }
                    if(naoTem) {
                        pedido.getBebidas().add(b);
                    }
                    Toast.makeText(MainActivity.this,"Adicionado " + b.getNome(),Toast.LENGTH_SHORT).show();

                }
            });

            replaceFragment(bebidaFragment,"bebida");
        } else if (id == R.id.nav_categorias) {
            Fragment categoriaFragment = fragmentManager.findFragmentByTag("categoria");
            if (categoriaFragment == null) {
                categoriaFragment = new CategoriaFragment();
            }
            replaceFragment(categoriaFragment, "categoria");
            Toast.makeText(MainActivity.this, "Você entrou no menu categorias", Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_meucarrinho) {
            Fragment pedidoFragment = fragmentManager.findFragmentByTag("pedido");
            if(pedidoFragment == null){
                pedidoFragment = new PedidoFragmento();
            }
            ((PedidoFragmento)pedidoFragment).setArgumentsPedido(pedido);
            ((PedidoFragmento)pedidoFragment).setArgumentsPedidoBebidas(pedido);
            replaceFragment(pedidoFragment,"pedido");

            Toast.makeText(MainActivity.this , "Você entrou no menu Meu carrinho",Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_meuperfil) {
            Fragment perfilFragment = fragmentManager.findFragmentByTag("perfil");
            if(perfilFragment == null){
                perfilFragment = new PerfilFragment();
            }
            replaceFragment(perfilFragment,"perfil");
            Toast.makeText(MainActivity.this , "Você entrou no menu meu perfil",Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_cadastrar) {
            Fragment cadastroFragment = fragmentManager.findFragmentByTag("cadastro");
            if(cadastroFragment == null){
                cadastroFragment = new CadastroFragment();
            }
            replaceFragment(cadastroFragment,"cadastro");
            Toast.makeText(MainActivity.this , "Você entrou no menu cadastro",Toast.LENGTH_SHORT).show();
        } else if (id == R.id.nav_sobre) {
            Fragment sobreFragment = fragmentManager.findFragmentByTag("sobre");
            if(sobreFragment == null){
                sobreFragment = new SobreFragment();
            }
            replaceFragment(sobreFragment, "sobre");
            Toast.makeText(MainActivity.this , "Você entrou no menu Sobre",Toast.LENGTH_SHORT).show();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void replaceFragment(Fragment fragment, String tag){
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame,fragment,tag);
        fragmentTransaction.addToBackStack(null);
        //fragmentManager.popBackStack(tag, fragmentManager.POP_BACK_STACK_INCLUSIVE);
        fragmentTransaction.commit();
    }
}
