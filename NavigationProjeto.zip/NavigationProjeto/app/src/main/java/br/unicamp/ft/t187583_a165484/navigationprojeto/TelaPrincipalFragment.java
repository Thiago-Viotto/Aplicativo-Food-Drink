package br.unicamp.ft.t187583_a165484.navigationprojeto;


import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;

import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnBebidaRequest;
import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnCadastroRequest;
import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnCardapioRequest;
import br.unicamp.ft.t187583_a165484.navigationprojeto.Interfaces.OnCategoriaRequest;


/**
 */
public class TelaPrincipalFragment extends android.support.v4.app.Fragment {
    View view;
    private ImageView imgNossosPratos, imgNossasBebidas, imgNossasCategorias;
    private Button btnEntrar, btnCadastrar;
    private OnCardapioRequest onCardapioRequest;
    private OnBebidaRequest onBebidaRequest;
    private MyFirstAdapter mAdapter;
    private OnCategoriaRequest onCategoriaRequest;
    private OnCadastroRequest onCadastroRequest;
    PedidoFragmento p = new PedidoFragmento();


    public TelaPrincipalFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(view == null){
            view = inflater.inflate(R.layout.fragment_tela_principal, container, false);
        }

        imgNossosPratos = view.findViewById(R.id.imgNossosPratos);
        imgNossasBebidas = view.findViewById(R.id.imgNossasBebidas);
        imgNossasCategorias = view.findViewById(R.id.imgNossasCategorias);
        btnCadastrar = view.findViewById(R.id.btnCadastrarTelaInicial);
        mAdapter = new MyFirstAdapter(new ArrayList(Arrays.asList(Comidas.comidas)));

        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onCardapioRequest != null) {
                    onCardapioRequest.request();
                }
                Toast.makeText(getContext(),"Você entrou no menu cardápio",Toast.LENGTH_SHORT).show();
            }
        };
        imgNossosPratos.setOnClickListener(onClickListener);

        View.OnClickListener onClickListener1 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onBebidaRequest != null) {
                    onBebidaRequest.onRequest();
                }
                Toast.makeText(getContext(),"Você entrou no menu bebidas",Toast.LENGTH_SHORT).show();
            }
        };
        imgNossasBebidas.setOnClickListener(onClickListener1);

        View.OnClickListener onClickListener2 = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onCategoriaRequest != null) {
                    onCategoriaRequest.request();
                }
                Toast.makeText(getContext(),"Você clicou no nossas categorias",Toast.LENGTH_SHORT).show();
            }
        };
        imgNossasCategorias.setOnClickListener(onClickListener2);

        View.OnClickListener onClickListener3 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(onCadastroRequest != null){
                    onCadastroRequest.request();
                }
                Toast.makeText(getContext(),"Você clicou no menu cadastro",Toast.LENGTH_SHORT).show();
            }
        };
        btnCadastrar.setOnClickListener(onClickListener3);

        mAdapter.setMyButtonOnItemClickListener(new MyFirstAdapter.MyButtonOnItemClickListener() {
            @Override
            public void myButtonOnItemClick(int pos) {
                if (onCardapioRequest != null) {
                    onCardapioRequest.requestList(Comidas.comidas[pos], pos);
                }
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    public void setOnCardapioRequest(OnCardapioRequest onCardapioRequest) {
        this.onCardapioRequest = onCardapioRequest;
    }

    public void setOnBebidaRequest(OnBebidaRequest onBebidaRequest) {
        this.onBebidaRequest = onBebidaRequest;
    }

    public void setOnCategoriaRequest(OnCategoriaRequest onCategoriaRequest) {
        this.onCategoriaRequest = onCategoriaRequest;
    }

    public void setOnCadastroRequest(OnCadastroRequest onCadastroRequest) {
        this.onCadastroRequest = onCadastroRequest;
    }

}
