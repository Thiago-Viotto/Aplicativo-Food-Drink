package br.unicamp.ft.t187583_a165484.navigationprojeto;


import android.app.DatePickerDialog;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;


/**
 * A simple {@link Fragment} subclass.
 */
public class CadastroFragment extends android.support.v4.app.Fragment {
    private ImageView imageView;
    private EditText date,nome,cpf,endereco,cidade,telefone,email,usuario,senha;
    private RadioGroup tipoPessoa;
    private DatePickerDialog datePickerDialog;
    private Spinner spinnerPais;
    private Spinner spinnerEstados;
    private Button btnCalcular;
    private CheckBox concordo;
    View view;


    public CadastroFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (view == null){
            view = inflater.inflate(R.layout.fragment_cadastro, container, false);
        }

        spinnerPais = view.findViewById(R.id.spinnerPais);
        spinnerEstados = view.findViewById(R.id.spinnerEstado);
        tipoPessoa = view.findViewById(R.id.tipopessoa);
        nome = view.findViewById(R.id.nomeEmpresa);
        cpf = view.findViewById(R.id.cpf);
        endereco = view.findViewById(R.id.endereco);
        cidade = view.findViewById(R.id.cidade);
        telefone = view.findViewById(R.id.telefone);
        email = view.findViewById(R.id.email);
        usuario = view.findViewById(R.id.usuario);
        senha = view.findViewById(R.id.senha);
        concordo = view.findViewById(R.id.concordoCheckBox);
        btnCalcular = view.findViewById(R.id.btnCadastrar);
        criaData();
        criaSpinner(spinnerPais);  //cria spinner dos paises
        criaSpinner(spinnerEstados);  //cria spinner dos estados
        concordo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean checked = ((CheckBox)view).isChecked();
                switch (view.getId()){
                    case R.id.concordoCheckBox:
                        if (checked) {
                            Toast.makeText(getContext(), "Você concordou com os termos e condições ", Toast.LENGTH_SHORT).show();
                            break;
                        }
                }
            }
        });
        tipoPessoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean checked = ((RadioButton)view).isChecked();
                switch (view.getId()){
                    case R.id.fisica:
                        if(checked) {
                            Toast.makeText(getContext(), "Você selecionou pessoa física", Toast.LENGTH_SHORT).show();
                            break;
                        }
                    case R.id.juridica:
                        if(checked) {
                            Toast.makeText(getContext(), "Você selecionou pessoa jurídica", Toast.LENGTH_SHORT).show();
                            break;
                        }
                }
            }
        });

        onClickBtnCadastrar();
        // Inflate the layout for this fragment
        return view;
    }

    public void onClickBtnCadastrar(){
        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nomeEmpresa = nome.getText().toString();
                String cpfCnpj = cpf.getText().toString();
                String endereco2 = endereco.getText().toString();
                String cidade2 = cidade.getText().toString();
                String fone = telefone.getText().toString();
                String mail = email.getText().toString();
                String user = usuario.getText().toString();
                String password = senha.getText().toString();
            }
        };
        btnCalcular.setOnClickListener(onClickListener);
    }

    public void criaSpinner(Spinner spinner){
        AdapterView.OnItemSelectedListener itemSelectedListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String txt = ((TextView)view).getText().toString();
                Toast.makeText(getContext(),"Você selecionou "+adapterView.getItemAtPosition(position).toString(),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };
        spinner.setOnItemSelectedListener(itemSelectedListener);
    }

    /* DATA CALENDÁRIO  ********************************************************************************************************************/
    public void criaData(){
        date = view.findViewById(R.id.date);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // ano
                int mMonth = c.get(Calendar.MONTH); // mes
                int mDay = c.get(Calendar.DAY_OF_MONTH); // dia

                datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int ano, int mes, int dia) {
                        // seta dia, mes e ano com barras
                        date.setText(dia + "/" + (mes + 1) + "/" + ano);
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });
    }

    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
    }

}
